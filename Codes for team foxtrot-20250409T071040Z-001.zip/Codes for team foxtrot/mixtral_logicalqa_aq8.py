import time
import re
import pandas as pd
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig

#  load a quantized model (8-bit)
quant_config = BitsAndBytesConfig(load_in_8bit=True)

class mixtral(torch.nn.Module):
    def __init__(self, model_name, device):
        super().__init__()
        self.device = device
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, quantization_config=quant_config)
        self.tokenizer.pad_token = self.tokenizer.eos_token

    def forward(self, question):
        encoded_input = self.tokenizer.encode_plus(
            question, 
            return_tensors="pt", 
            padding=True, 
            truncation=True).to(self.device)

        generated_ids = self.model.generate(
            **encoded_input,
            max_new_tokens=1000,
            do_sample=True
        )

        answer = self.tokenizer.decode(generated_ids[0], skip_special_tokens=True)
        return answer
    
def process_text_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read().strip()
    
    paragraphs = content.split('\n\n')
    processed_paragraphs = [' '.join(paragraph.split('\n')) for paragraph in paragraphs]
    answers = [paragraph[0].upper() for paragraph in processed_paragraphs if len(paragraph) > 0]
    questions = [paragraph[2:] for paragraph in processed_paragraphs if len(paragraph) > 1]

    return answers, questions
    
device = "cuda" if torch.cuda.is_available() else "cpu"
model_name = "mistralai/Mistral-7B-Instruct-v0.2"
float_model = mixtral(model_name, device).to(device)

pattern = re.compile(r"(?:Answer[s]?|I'd say|I answered|As I see it,|my answer|answer is|answer this question:|answer:|\*\*My answer is:\*\*)\s*:?[\s\*]*['\"\(\[]?\s*([A-D])\s*['\"\)\]\.]?\.?\s*")

"""
test_sentences = [
    "Answer: C.",
    "My answer is [A].",
    "Let me directly answer this question: D.",
    "My answer is : A.",
    "My answer is: 'A.",
    "My answer is (D).",
    "(Answer: D)",
    "My answer is: 'D.",
    "here is my answer: A.",
    "I answered: C.",
    "As I see it, C is the answer.",
    "My answer is: [B.",
    "My answer is: B.",
    "s answer: C.",
    "**My answer is:** C.",
    "I'd say: C.",
    "Answer:C.",
    "My answer is [D].",
    "My answer is : A.",
    "My answer is (D).",
    "My answer is: 'D."
]
"""
file_path = 'Train.txt'
answers, questions = process_text_file(file_path)
answers_p_options, answers_p_fulls = [], []

for i, question in enumerate(questions, start=1):
    
    question = f"From options [A,B,C,D], give me one to answer this question directly like 'My answer is ...': '{question}'"

    print("=" *50)
    formatted_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print("Formatted local time:", formatted_time)
    print(f"Question {i}: {question}\n")
    print(f"True Answer is {answers[i - 1]}\n")
        
    answer_p = float_model(question)
    print(f"Predicted Answer: {answer_p}\n")
    match = pattern.search(answer_p)
    if match:
        answers_p_option = match.group(1)
    else:
        answers_p_option = 'Not Found'
    answers_p_options.append(answers_p_option)
    answers_p_fulls.append(answer_p[len(question):])
    
print(len(answers), len(questions), len(answers_p_options), len(answers_p_fulls))
df = pd.DataFrame({
    'Questions': questions,
    'True Answers': answers,
    'Predicted Answers': answers_p_options,
    'Predicted Whole Result': answers_p_fulls
})

df.to_csv('mixtral1_logicalqa_aq8.csv', index=False, encoding='utf-8-sig')