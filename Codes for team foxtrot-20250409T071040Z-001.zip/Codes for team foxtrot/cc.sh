#!/bin/bash
#SBATCH --job-name=commonsense_new  # Replace JOB_NAME with a name you like
#SBATCH --time=96:00:00  # Change this to a longer time if you need more time
#SBATCH --partition=gpu
#SBATCH --qos=gpu
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=32
#SBATCH --mem=82G
#SBATCH --output=./Output/%x-%j.txt  # This is where your output and errors are logged
#SBATCH --mail-type=BEGIN,END,FAIL
#SBATCH --mail-user=yzhang797@sheffield.ac.uk  # Request job update email notifications, remove this line if you don't want to be notified

module load Java/17.0.4
module load Anaconda3/2022.05

source activate mixtral

cd /users/acs23yz/team/

#python commonsense.py
#python commonsense.py --quantization 4
#python commonsense.py --quantization 8
#python commonsense.py --quantization 16

#python commonsense.py --model_name meta-llama/Meta-Llama-3-8B-Instruct
#python commonsense.py --model_name meta-llama/Meta-Llama-3-8B-Instruct --quantization 4
#python commonsense.py --model_name meta-llama/Meta-Llama-3-8B-Instruct --quantization 8
#python commonsense.py --model_name meta-llama/Meta-Llama-3-8B-Instruct --quantization 16

python commonsense.py --model_name meta-llama/Llama-2-7b-hf
python commonsense.py --model_name meta-llama/Llama-2-7b-hf --quantization 4
python commonsense.py --model_name meta-llama/Llama-2-7b-hf --quantization 8
python commonsense.py --model_name meta-llama/Llama-2-7b-hf --quantization 16

python commonsense.py --model_name meta-llama/Llama-2-13b-hf
python commonsense.py --model_name meta-llama/Llama-2-13b-hf --quantization 4
python commonsense.py --model_name meta-llama/Llama-2-13b-hf --quantization 8
python commonsense.py --model_name meta-llama/Llama-2-13b-hf --quantization 16