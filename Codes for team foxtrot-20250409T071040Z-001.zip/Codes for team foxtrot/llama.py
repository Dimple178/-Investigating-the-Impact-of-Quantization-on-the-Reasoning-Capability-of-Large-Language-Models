import time
import re
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer

class mixtral(torch.nn.Module):
    def __init__(self, model_name, device):
        super().__init__()
        self.device = device
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token

    def forward(self, questions):
        encoded_input = self.tokenizer(
            questions, 
            return_tensors="pt", 
            padding=True,
            truncation=True
        ).to(self.device)

        generated_ids = self.model.generate(
            **encoded_input,
            max_length=encoded_input['input_ids'].shape[1] + 100, 
            max_new_tokens=100,
            do_sample=True
        )

        answers = [self.tokenizer.decode(generated_id, skip_special_tokens=True) for generated_id in generated_ids]
        return answers
    
class TextDataset(Dataset):
    def __init__(self, file_path):
        self.answers, self.questions = self.process_text_file(file_path)

    def __len__(self):
        return len(self.questions)

    def __getitem__(self, idx):
        question = self.questions[idx]
        answer = self.answers[idx]
        formatted_question = f"From options [A,B,C,D], give me one to answer this question directly like 'My answer is ...': '{question}'"
        return formatted_question, answer

    @staticmethod
    def process_text_file(file_path):
        with open(file_path, 'r') as file:
            content = file.read().strip()
        
        paragraphs = content.split('\n\n')
        processed_paragraphs = [' '.join(paragraph.split('\n')) for paragraph in paragraphs]
        answers = [paragraph[0].upper() for paragraph in processed_paragraphs if len(paragraph) > 0]
        questions = [paragraph[2:] for paragraph in processed_paragraphs if len(paragraph) > 1]
    
        return answers, questions
        
def batch_predict(model, questions):
    predictions = model(questions)
    
    predicted_answers = []
    
    pattern = re.compile(
    r"(?:Answer[s]?|I'd say|I answered|As I see it,|my answer|Answer is|Answer this question:|Answer:|\*\*My answer is:\*\*|I would say:|It is my answer that:|I'd go for|I'm going with|I'll go with option|The answer I would give is:)\s*:?[\s\*]*['\"\(\[]?\s*Option\s*([A-D])\s*['\"\)\]\.]?\.?|(?<!\w)([A-D])(?!\w)",
    re.IGNORECASE)
    
    for predicted_answer in predictions:
        match = pattern.search(predicted_answer)
        if match:
            predicted_answers.append(re.sub(r"[^A-D]", "", match.group(0)))
        else:
            predicted_answers.append('Not Found')
    
    return predicted_answers, predictions
    
device = "cuda" if torch.cuda.is_available() else "cpu"
model_name = "meta-llama/Meta-Llama-3-8B-Instruct"
model = mixtral(model_name, device).to(device)

dataset = TextDataset('Train.txt')
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)
answers_p_options, answers_p_fulls = [], []
questions, answers = [], []

for batch in dataloader:
    formatted_questions, true_answers = batch
    predicted_answers, predictions = batch_predict(model, formatted_questions)
    print("=" * 50)
    formatted_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print("Formatted local time:", formatted_time)
    
    print(f"Question: {formatted_questions[0]}\n")
    print(f"True Answer is {true_answers[0]}\n")
    print(f"Predicted Option: {predicted_answers[0]}\n")
    print(f"Predicted Answer: {predictions[0]}\n")
    
    questions.extend(formatted_questions)
    answers.extend(true_answers)
    answers_p_options.extend(predicted_answers)
    answers_p_fulls.extend(predictions)
        
    
df = pd.DataFrame({
    'Questions': questions,
    'True Answers': answers,
    'Predicted Answers': answers_p_options,
    'Predicted Whole Result': answers_p_fulls
})

df.to_csv('New_llama_logicalqa_bq_demo.csv', index=False, encoding='utf-8-sig')

print(len(answers), len(questions), len(answers_p_options), len(answers_p_fulls))