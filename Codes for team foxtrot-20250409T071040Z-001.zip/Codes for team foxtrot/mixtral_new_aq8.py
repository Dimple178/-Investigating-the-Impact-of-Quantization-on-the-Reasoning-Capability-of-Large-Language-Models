import argparse
import time
import re
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers import BitsAndBytesConfig

# 8 bits quantization
quant_config = BitsAndBytesConfig(load_in_8bit=True)

class mixtral(torch.nn.Module):
    def __init__(self, model_name, device):
        super().__init__()
        self.device = device
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, quantization_config=quant_config)
        self.tokenizer.pad_token = self.tokenizer.eos_token

    def forward(self, questions):
        encoded_input = self.tokenizer(
            questions, 
            return_tensors="pt", 
            padding=True,
            truncation=True
        ).to(self.device)

        generated_ids = self.model.generate(
            **encoded_input,
            max_length=encoded_input['input_ids'].shape[1] + 100, 
            max_new_tokens=100,
            do_sample=True
        )

        answers = [self.tokenizer.decode(generated_id, skip_special_tokens=True) for generated_id in generated_ids]
        return answers
    
class TextDataset(Dataset):
    def __init__(self, file_path):
        self.answers, self.questions = self.process_text_file(file_path)

    def __len__(self):
        return len(self.questions)

    def __getitem__(self, idx):
        question = self.questions[idx]
        answer = self.answers[idx]
        formatted_question = f"From options [A,B,C,D], give me one to answer this question directly like 'My answer is ...': '{question}'"
        return formatted_question, answer

    @staticmethod
    def process_text_file(file_path):
        with open(file_path, 'r') as file:
            content = file.read().strip()
        
        paragraphs = content.split('\n\n')
        processed_paragraphs = [' '.join(paragraph.split('\n')) for paragraph in paragraphs]
        answers = [paragraph[0].upper() for paragraph in processed_paragraphs if len(paragraph) > 0]
        questions = [paragraph[2:] for paragraph in processed_paragraphs if len(paragraph) > 1]
    
        return answers, questions
        
def batch_predict(model, questions):
    predictions = model(questions)
    return predictions
    
device = "cuda" if torch.cuda.is_available() else "cpu"
model_name = "mistralai/Mistral-7B-Instruct-v0.2"
model = mixtral(model_name, device).to(device)

pattern = re.compile(
    r"(?:Answer[s]?|I'd say|I answered|As I see it,|my answer|answer is|answer this question:|answer:|\*\*My answer is:\*\*|I would say:|It is my answer that:|I'd go for|I'm going with|I'll go with option|The answer I would give is:)\s*:?[\s\*]*['\"\(\[]?\s*Option\s*([A-D])|([A-D])\s*['\"\)\]\.]?\.?\s*",
    re.IGNORECASE
)

dataset = TextDataset('Train.txt')
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)
answers_p_options, answers_p_fulls = [], []
questions, answers = [], []

for batch in dataloader:
    formatted_questions, true_answers = batch
    predicted_answers = batch_predict(model, formatted_questions)
    print("=" * 50)
    formatted_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print("Formatted local time:", formatted_time)
    
    print(f"Question: {formatted_questions[0]}\n")
    print(f"True Answer is {true_answers[0]}\n")
    predicted_answers = [predicted_answer[len(formatted_questions[0]):] for predicted_answer in predicted_answers]
    print(f"Predicted Answer: {predicted_answers[0]}\n")
    
    questions.extend(formatted_questions)
    answers.extend(true_answers)
    answers_p_fulls.extend(predicted_answers)
    
    for predicted_answer in predicted_answers:
        match = pattern.search(predicted_answer)
        if match:
            answer_p_option = match.group(1)
        else:
            answer_p_option = 'Not Found'
            
        answers_p_options.append(answer_p_option)
        
    
df = pd.DataFrame({
    'Questions': questions,
    'True Answers': answers,
    'Predicted Answers': answers_p_options,
    'Predicted Whole Result': answers_p_fulls
})

df.to_csv('New_mix_logicalqa_aq8.csv', index=False, encoding='utf-8-sig')

print(len(answers), len(questions), len(answers_p_options), len(answers_p_fulls))