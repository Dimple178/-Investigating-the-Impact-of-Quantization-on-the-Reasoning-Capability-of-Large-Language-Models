import argparse
import time
import re
import pandas as pd
import torch
import json
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers import BitsAndBytesConfig

parser = argparse.ArgumentParser(description="Run the Mixtral model with specified model and device.")

parser.add_argument("--model_name", "-m", type=str, default="mistralai/Mistral-7B-Instruct-v0.2",
                        help="The model name to load with the transformer.")
parser.add_argument("--device", type=str, default="cuda",
                    help="The device type to run the model on.")
parser.add_argument("--quantization", type=int, default=0,
                    help="model quantization (4, 8, 16 bits accepted).")

args = parser.parse_args()

try:
    model_name = re.search(r"/([^Bb]*)[Bb]", args.model_name).group(1)
except AttributeError:
    model_name = args.model_name

print(f"Using model {model_name}")

if args.quantization in [2, 3, 4, 8, 16]:
    print(f"Quantization for {args.quantization} bits")
    filename = f'SIQA_{model_name}_aq{args.quantization}.csv'
else:
    print("No quantization")
    filename = f'SIQA_{model_name}_bq.csv'
    
datapath = 'SIQA/socialIQa_v1.4_tst.jsonl'
    
print(f'The datasets are from {datapath}')
print(f"The result will be saved as {filename}")

class mixtral(torch.nn.Module):
    def __init__(self, model_name, device, q):
        super().__init__()
        self.device = device
        if q == 2 or q == 3:
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
            quantization_config = GPTQConfig(bits=q, dataset = "c4", tokenizer=self.tokenizer)
            self.model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=quantization_config)
        elif q == 4:
            self.model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto")
            self.tokenizer = AutoTokenizer.from_pretrained(model_name, load_in_4bit=True)
        elif q == 8:
            self.model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto")
            self.tokenizer = AutoTokenizer.from_pretrained(model_name, load_in_8bit=True)
        elif q == 16:
            self.model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch.bfloat16, device_map="auto")
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        else:
            self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token

    def forward(self, questions):
        encoded_input = self.tokenizer(
            questions, 
            return_tensors="pt", 
            padding=True,
            truncation=True
        ).to(self.device)

        generated_ids = self.model.generate(
            **encoded_input,
            max_length=encoded_input['input_ids'].shape[1] + 100, 
            max_new_tokens=100,
            do_sample=True
        )

        answers = [self.tokenizer.decode(generated_id, skip_special_tokens=True) for generated_id in generated_ids]
        return answers
    
class TextDataset(Dataset):
    def __init__(self, file_path):
        self.answers, self.questions = self.process_text_file(file_path)

    def __len__(self):
        return len(self.questions)

    def __getitem__(self, idx):
        question = self.questions[idx]
        answer = self.answers[idx]
        formatted_question = f"From options [A,B,C], give me one to answer this question directly like 'My answer is ...': '{question}'"
        return formatted_question, answer

    @staticmethod
    def process_text_file(file_path):
        data = []
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                data.append(json.loads(line))
        
        answers = [sentence['correct'] for sentence in data]
        questions = [f'{sentence["context"]} {sentence["question"]} A: {sentence["answerA"]}, B: {sentence["answerB"]}, C: {sentence["answerC"]}.' for sentence in data]
    
        return answers, questions
        
def batch_predict(model, questions):
    predictions = model(questions)
    predictions = [prediction[len(questions[i]):] for i, prediction in enumerate(predictions)]
    
    predicted_answers = []
    
    pattern = re.compile(
    r"(?:Answer[s]?|I'd say|I answered|As I see it,|my answer|Answer is|Answer this question:|Answer:|\*\*My answer is:\*\*|I would say:|It is my answer that:|I'd go for|I'm going with|I'll go with option|The answer I would give is:)\s*:?[\s\*]*['\"\(\[]?\s*Option\s*([A-C])\s*['\"\)\]\.]?\.?|(?<!\w)([A-C])(?!\w)",
    re.IGNORECASE)
    
    for predicted_answer in predictions:
        match = pattern.search(predicted_answer)
        if match:
            predicted_answers.append(re.sub(r"[^A-C]", "", match.group(0)))
        else:
            predicted_answers.append('Not Found')
    
    print(predicted_answers)
    
    return predicted_answers, predictions
    
device = "cuda"
model_name = args.model_name
model = mixtral(model_name, device, args.quantization)

dataset = TextDataset(datapath)
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)
answers_p_options, answers_p_fulls = [], []
questions, answers = [], []

for batch in dataloader:
    formatted_questions, true_answers = batch
    predicted_answers, predictions = batch_predict(model, formatted_questions)
    print("=" * 50)
    formatted_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print("Formatted local time:", formatted_time)
    
    print(f"Question: {formatted_questions[0]}\n")
    print(f"True Answer is {true_answers[0]}\n")
    print(f"Predicted Option: {predicted_answers[0]}\n")
    print(f"Predicted Answer: {predictions[0]}\n")
    
    questions.extend(formatted_questions)
    answers.extend(true_answers)
    answers_p_options.extend(predicted_answers)
    answers_p_fulls.extend(predictions)
        
    
df = pd.DataFrame({
    'Questions': questions,
    'True Answers': answers,
    'Predicted Answers': answers_p_options,
    'Predicted Whole Result': answers_p_fulls
})

df.to_csv(filename, index=False, encoding='utf-8-sig')

print(len(answers), len(questions), len(answers_p_options), len(answers_p_fulls))                 