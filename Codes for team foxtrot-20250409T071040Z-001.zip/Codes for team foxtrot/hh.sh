#!/bin/bash
#SBATCH --job-name=mixtral_8x7B_new  # Replace JOB_NAME with a name you like
#SBATCH --time=96:00:00  # Change this to a longer time if you need more time
#SBATCH --partition=gpu
#SBATCH --qos=gpu
#SBATCH --gres=gpu:2
#SBATCH --cpus-per-task=32
#SBATCH --mem=160G
#SBATCH --output=./Output/%x-%j.txt  # This is where your output and errors are logged
#SBATCH --mail-type=BEGIN,END,FAIL
#SBATCH --mail-user=yzhang797@sheffield.ac.uk  # Request job update email notifications, remove this line if you don't want to be notified

module load Java/17.0.4
module load Anaconda3/2022.05

source activate mixtral

cd /users/acs23yz/team/

python logicQa.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1
python logicQa.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 4
python logicQa.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 8
python logicQa.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 16

python siqa.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1
python siqa.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 4
python siqa.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 8
python siqa.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 16

python commonsense.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1
python commonsense.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 4
python commonsense.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 8
python commonsense.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 16

python aqua.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1
python aqua.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 4
python aqua.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 8
python aqua.py --model_name mistralai/Mixtral-8x7B-Instruct-v0.1 --quantization 16