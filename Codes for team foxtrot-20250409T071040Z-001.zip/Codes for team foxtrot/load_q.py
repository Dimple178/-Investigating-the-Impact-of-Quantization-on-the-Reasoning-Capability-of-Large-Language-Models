import time
import re
import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, GPTQConfig
from torch.utils.data import Dataset, DataLoader

device = "cuda" if torch.cuda.is_available() else "cpu"
model_name = "mistralai/Mistral-7B-Instruct-v0.2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
tokenizer.pad_token = tokenizer.eos_token
quantization_bits = 8
quantization_config = GPTQConfig(bits=quantization_bits, dataset = "c4", tokenizer=tokenizer)
model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=quantization_config)

def process_text_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read().strip()
    
    paragraphs = content.split('\n\n')
    processed_paragraphs = [' '.join(paragraph.split('\n')) for paragraph in paragraphs]
    answers = [paragraph[0].upper() for paragraph in processed_paragraphs if len(paragraph) > 0]
    questions = [paragraph[2:] for paragraph in processed_paragraphs if len(paragraph) > 1]

    return answers, questions

pattern = re.compile(r"(?:Answer[s]?|I'd say|I answered|As I see it,|my answer|answer is|answer this question:|answer:|\*\*My answer is:\*\*)\s*:?[\s\*]*['\"\(\[]?\s*([A-D])\s*['\"\)\]\.]?\.?\s*")

file_path = 'Train.txt'
answers, questions = process_text_file(file_path)
answers_p_options, answers_p_fulls = [], []

for i, question in enumerate(questions):
    
    prompt = f"From options [A,B,C,D], give me one to answer this question directly like 'My answer is ...': '{question}'"
    
    encoded_input = tokenizer.encode_plus(
            prompt, 
            return_tensors="pt", 
            padding=True, 
            truncation=True).to(device)

    generated_ids = model.generate(
        **encoded_input,
        max_new_tokens=1000
    )
    
    answer_p = tokenizer.decode(generated_ids[0], skip_special_tokens=True)
        
    match = pattern.search(answer_p)
    if match:
        answers_p_option = match.group(1)
    else:
        answers_p_option = 'Not Found'
        
    if i % 100 == 0:
        print("=" *50)
        formatted_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        print("Formatted local time:", formatted_time)
        print(f"Question {i}: {question}\n")
        print(f"True Answer is {answers[i]}\n")
        print(f"Predicted Answer: {answer_p}\n")
    answers_p_options.append(answers_p_option)
    answers_p_fulls.append(answer_p[len(question):])
    
print(len(answers), len(questions), len(answers_p_options), len(answers_p_fulls))
df = pd.DataFrame({
    'Questions': questions,
    'True Answers': answers,
    'Predicted Answers': answers_p_options,
    'Predicted Whole Result': answers_p_fulls
})

df.to_csv(f'mixtral_logicalqa_aq_{quantization_bits}.csv', index=False, encoding='utf-8-sig')
