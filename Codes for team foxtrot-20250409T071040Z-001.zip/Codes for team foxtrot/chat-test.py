import time
import re
import pandas as pd
import torch

from transformers import AutoModelForCausalLM, AutoTokenizer

device = "cuda" if torch.cuda.is_available() else "cpu"

model = AutoModelForCausalLM.from_pretrained("gpt2")
tokenizer = AutoTokenizer.from_pretrained("gpt2")

documents =  ['Sammy wanted to go to where the people were.', 'To locate a choker not located in a jewelry box or boutique ']
  
questions = ['Where might he go? A: race track, B: populated areas, C: the desert, D: apartment, E: roadblock.', 'where would you go? A: jewelry store, B: neck, C: jewlery box, D: jewelry box, E: boutique.']

messages = []

for document, question in zip(documents, questions):
    message = [
        {"role": "user", "content": "You are a helpful assistant that answers truthfully any question based on the context given."},
        {"role": "user", "content": f" Context: {document} Question: {question} Answer:"}
    ]
    
    messages.append(message)
    
print(messages)

encodeds = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True, return_tensors="pt")
print(tokenizer.decode(encodeds[1]))

model_inputs = encodeds.to(device)
model.to(device)

generated_ids = model.generate(model_inputs, max_new_tokens=100, do_sample=True)
decoded = tokenizer.batch_decode(generated_ids)
print(decoded)
print(len(decoded))