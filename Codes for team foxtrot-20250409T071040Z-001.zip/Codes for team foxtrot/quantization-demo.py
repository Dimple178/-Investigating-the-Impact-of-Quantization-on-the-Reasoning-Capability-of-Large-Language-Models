import time
import re
import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, GPTQConfig

class mixtral(torch.nn.Module):
    '''
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    tokenizer.pad_token = tokenizer.eos_token
    quantization_config = GPTQConfig(bits=4, dataset = "c4", tokenizer=tokenizer)
    
    model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=quantization_config)
    
    encoded_input = tokenizer.encode_plus(
                message, 
                return_tensors="pt", 
                padding=True, 
                truncation=True).to(device)
    
    generated_ids = model.generate(
        **encoded_input,
        max_new_tokens=1000,
        do_sample=True
    )
    
    answer = tokenizer.decode(generated_ids[0], skip_special_tokens=True)
    '''
    def __init__(self, model_name, device):
        super().__init__()
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token
        self.quantization = GPTQConfig(bits=8, dataset="c4", tokenizer=self.tokenizer)
        self.model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=self.quantization).to(self.device)

    def forward(self, question):
        encoded_input = self.tokenizer.encode_plus(
            question, 
            return_tensors="pt", 
            padding=True, 
            truncation=True).to(self.device)

        generated_ids = self.model.generate(
            **encoded_input,
            max_new_tokens=1000
        )

        answer = self.tokenizer.decode(generated_ids[0], skip_special_tokens=True)
        return answer

def process_text_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read().strip()
    
    paragraphs = content.split('\n\n')
    processed_paragraphs = [' '.join(paragraph.split('\n')) for paragraph in paragraphs]
    answers = [paragraph[0].upper() for paragraph in processed_paragraphs if len(paragraph) > 0]
    questions = [paragraph[2:] for paragraph in processed_paragraphs if len(paragraph) > 1]

    return answers, questions


message = "From options [A,B,C,D], give me one to answer this question directly like 'My answer is ...': 'An indigenous person tests the physical fitness of newborn babies in order to improve the combat effectiveness of their offspring.They place newborn babies in a harsh natural environment to test their vitality, and abandon those who are weak and cannot stand the test, and leave those sturdy babies.This method did not make the local indigenous people strong but declined. Which of the following is most appropriate as the cause of the eventual failure of local talent selection? A.The physical fitness of newborn babies is good, but they may not be stronger when they grow up. B.Physiological quality is only part of a person's overall quality, and national security requires the improvement of a person's comprehensive quality C.Talents are selected, but too few are inevitable D.The child's parents are unhappy with the brutal selection method and are unwilling to defend their city'"

device = "cuda" if torch.cuda.is_available() else "cpu"
model_name = "mistralai/Mistral-7B-Instruct-v0.2"
float_model = mixtral(model_name, device).to(device)
answer = float_model(message)

print(answer)

pattern = re.compile(r"(?:Answer[s]?|I'd say|I answered|As I see it,|my answer|answer is|answer this question:|answer:|\*\*My answer is:\*\*)\s*:?[\s\*]*['\"\(\[]?\s*([A-D])\s*['\"\)\]\.]?\.?\s*")

"""
test_sentences = [
    "Answer: C.",
    "My answer is [A].",
    "Let me directly answer this question: D.",
    "My answer is : A.",
    "My answer is: 'A.",
    "My answer is (D).",
    "(Answer: D)",
    "My answer is: 'D.",
    "here is my answer: A.",
    "I answered: C.",
    "As I see it, C is the answer.",
    "My answer is: [B.",
    "My answer is: B.",
    "s answer: C.",
    "**My answer is:** C.",
    "I'd say: C.",
    "Answer:C.",
    "My answer is [D].",
    "My answer is : A.",
    "My answer is (D).",
    "My answer is: 'D."
]
"""

file_path = 'Train.txt'
answers, questions = process_text_file(file_path)
answers_p_options, answers_p_fulls = [], []

for i, question in enumerate(questions, start=1):
    
    question = f"From options [A,B,C,D], give me one to answer this question directly like 'My answer is ...': '{question}'"

    print("=" *50)
    formatted_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print("Formatted local time:", formatted_time)
    print(f"Question {i}: {question}\n")
    print(f"True Answer is {answers[i]}\n")
        
    answer_p = float_model(question)
    print(f"Predicted Answer: {answer_p}\n")
    match = pattern.search(answer_p)
    if match:
        answers_p_option = match.group(1)
    else:
        answers_p_option = 'Not Found'
    answers_p_options.append(answers_p_option)
    answers_p_fulls.append(answer_p[len(question):])
    
print(len(answers), len(questions), len(answers_p_options), len(answers_p_fulls))
df = pd.DataFrame({
    'Questions': questions,
    'True Answers': answers,
    'Predicted Answers': answers_p_options,
    'Predicted Whole Result': answers_p_fulls
})

df.to_csv('mixtral_logicalqa_aq_demo.csv', index=False, encoding='utf-8-sig')
